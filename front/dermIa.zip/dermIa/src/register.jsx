import React from "react";
import Navbar from "./components/navbar";

function Register() {
	return (
		<Navbar/>
	)
}

export default Register;