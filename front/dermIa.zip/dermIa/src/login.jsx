import React from "react";
import Navbar from "./components/navbar";

function Login() {
	return (
		<Navbar/>
	)
}

export default Login;